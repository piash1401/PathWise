
from rest_framework import serializers

from .models import Opportunity, OpportunitySource


class OpportunitySourceSerializer(serializers.ModelSerializer):
    is_stale = serializers.SerializerMethodField()

    class Meta:
        model = OpportunitySource
        fields = '__all__'

    def get_is_stale(self, obj):
        return obj.is_stale


class OpportunitySerializer(serializers.ModelSerializer):
    sources = OpportunitySourceSerializer(many=True, read_only=True)
    is_stale = serializers.SerializerMethodField()

    class Meta:
        model = Opportunity
        fields = '__all__'

    def get_is_stale(self, obj):
        return obj.is_stale