from datetime import date
from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase
from rest_framework.authtoken.models import Token
from rest_framework.test import APIClient

from costs.models import CountryCost, ExchangeRate
from profiles.models import StudentProfile

from .models import Opportunity
from .recommendations import field_match, recommend, score_opportunity


def make_opp(title, country='Germany', rules=None, **extra):
    return Opportunity.objects.create(
        opportunity_type=extra.pop('opportunity_type', 'program'), title=title,
        institution=extra.pop('institution', 'Test University'), country=country,
        eligibility_criteria='x', eligibility_rules=rules or {}, source_url='https://example.com',
        verified_on=date(2026, 11, 1), duration_months=extra.pop('duration_months', 24), **extra,
    )


class RecommendationTests(TestCase):

    def setUp(self):
        for country, currency, living in [('Germany', 'EUR', 992), ('UK', 'GBP', 1203)]:
            CountryCost.objects.create(
                country=country, currency=currency, living_per_month=living,
                proof_of_funds_per_year=living * 12, part_time_hourly_wage=12,
                part_time_max_hours_per_week=20, typical_tuition_per_year=0 if country == 'Germany' else 22000,
            )
        ExchangeRate.objects.create(currency='EUR', bdt_per_unit=Decimal('138.59'), as_of=date(2026, 11, 8))
        ExchangeRate.objects.create(currency='GBP', bdt_per_unit=Decimal('166.03'), as_of=date(2026, 11, 8))

        self.user = User.objects.create_user('s@e.com', 's@e.com', 'pw-Str0ng-123')
        self.profile = StudentProfile.objects.create(
            user=self.user, highest_degree="Bachelor's", field_of_study='Software Engineering',
            institution='DIU', graduation_year=2027, grade='3.94', grade_scale='4.00',
            english_test='IELTS', overall_score='7.5', annual_budget_bdt=1800000,
            destination_preferences=['Germany'], target_field='Computer Science',
        )
        self.client = APIClient()
        token = Token.objects.create(user=self.user)
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {token.key}')

    def test_field_match_uses_related_fields(self):
        cs = make_opp('MSc Computer Science', field_tags=['computing'])
        art = make_opp('MA History of Art')
        self.assertGreater(field_match(self.profile, cs)[0], 0.6)
        self.assertLess(field_match(self.profile, art)[0], 0.3)

    def test_preferred_cheap_matching_program_ranks_first(self):
        good = make_opp('MSc Computer Science', 'Germany')
        pricey = make_opp('MSc Data Science', 'UK', institution='UK Uni')
        results = recommend(self.profile, Opportunity.objects.all())
        self.assertEqual(results[0]['opportunity_id'], good.id)
        self.assertGreater(results[0]['score'], results[1]['score'])
        self.assertTrue(any('budget' in r for r in results[1]['reasons']))

    def test_unmet_requirement_caps_the_score(self):
        strict = make_opp('MSc Computer Science', 'Germany',
                          rules={'minimum_grade': 3.99, 'grade_scale': 4.0})
        result = score_opportunity(self.profile, strict)
        self.assertLessEqual(result['score'], 45)
        self.assertEqual(result['eligibility_status'], 'Not eligible')
        self.assertIn('Requirement not met', result['reasons'][0])

    def test_recommendations_endpoint(self):
        make_opp('MSc Computer Science', 'Germany')
        make_opp('DAAD Scholarship', 'Germany', opportunity_type='scholarship', institution='DAAD')
        response = self.client.get('/api/opportunities/recommendations/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data['results']), 1)  # scholarships are not ranked as programs

        only_uk = self.client.get('/api/opportunities/recommendations/?country=UK')
        self.assertEqual(only_uk.data['results'], [])

    def test_recommendations_need_login_and_profile(self):
        self.assertEqual(APIClient().get('/api/opportunities/recommendations/').status_code, 401)
        self.profile.delete()
        self.assertEqual(self.client.get('/api/opportunities/recommendations/').status_code, 404)

    def test_list_search_filter_and_detail(self):
        a = make_opp('MSc Computer Science', 'Germany', city='Bonn')
        make_opp('MSc Data Science', 'UK', institution='Other')
        anon = APIClient()
        self.assertEqual(len(anon.get('/api/opportunities/?q=bonn').data), 1)
        self.assertEqual(len(anon.get('/api/opportunities/?country=UK').data), 1)
        self.assertEqual(anon.get(f'/api/opportunities/{a.id}/').status_code, 200)
        self.assertEqual(anon.get('/api/opportunities/9999/').status_code, 404)

    def test_history_records_decimal_changes(self):
        opp = make_opp('MSc Computer Science', 'Germany')
        opp.tuition_per_year = Decimal('1500.00')
        opp.save()
        latest = opp.history.first()
        self.assertEqual(latest.changes['tuition_per_year']['new'], '1500.00')
