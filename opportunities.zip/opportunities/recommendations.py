"""
Program recommendations.

A transparent weighted score out of 100 (no black box, so you can explain it
to your instructor):

    40  eligibility   Met = full points, Unknown = half, Not met = none
    25  budget        estimated yearly cost compared with the student's budget
    15  destination   is the country one of the student's preferences?
    20  field         does the program match the student's field/target field?
"""

import re
from decimal import Decimal

from costs.services import CostDataMissing, estimate_cost

from .eligibility import check_eligibility

W_ELIGIBILITY, W_BUDGET, W_DESTINATION, W_FIELD = 40, 25, 15, 20

STOPWORDS = {
    'msc', 'ms', 'ma', 'mmath', 'master', 'masters', "master's", 'of', 'in', 'and', 'the',
    'a', 'degree', 'program', 'programme', 'study', 'studies', 'thesis', 'with', 'for',
    'bachelor', "bachelor's", 'b', 'sc', 'm', 'applied', 'international',
}

# Words that mean "the same area" for matching purposes.
CLUSTERS = {
    'cs': {'computer', 'computing', 'software', 'informatics', 'cs', 'swe', 'cse', 'programming',
           'information', 'systems', 'it', 'engineering'},
    'ai_data': {'data', 'analytics', 'ai', 'ml', 'artificial', 'intelligence', 'machine',
                'learning', 'science', 'statistics', 'deep'},
    'electrical': {'electrical', 'electronic', 'electronics', 'eee', 'telecommunication',
                   'communication', 'power'},
    'business': {'business', 'management', 'mba', 'economics', 'finance', 'marketing'},
    'mechanical': {'mechanical', 'mechatronics', 'robotics', 'manufacturing', 'industrial'},
    'civil': {'civil', 'architecture', 'construction', 'environmental'},
}


def _tokens(text):
    words = re.findall(r"[a-z']+", (text or '').lower())
    return {w for w in words if w not in STOPWORDS and len(w) > 1}


def _clusters(tokens):
    found = set()
    for name, words in CLUSTERS.items():
        if tokens & words:
            found.add(name)
    return found


def field_match(profile, opportunity):
    """Return (0..1, reason)."""
    query_text = profile.target_field or profile.field_of_study
    query = _tokens(query_text)

    if not query:
        return 0.5, 'Add your field of study or target field to improve matching.'

    doc = _tokens(' '.join([
        opportunity.title,
        ' '.join(opportunity.field_tags or []),
        opportunity.description,
    ]))

    exact = len(query & doc) / len(query)
    cluster_query, cluster_doc = _clusters(query), _clusters(doc)
    cluster = len(cluster_query & cluster_doc) / len(cluster_query) if cluster_query else 0

    score = min(1.0, max(exact, 0.7 * cluster + 0.3 * exact))

    if score >= 0.7:
        return score, f'Matches your interest in {query_text}.'
    if score >= 0.35:
        return score, f'Related to {query_text}.'
    return score, f'Not closely related to {query_text}.'


def _budget_points(profile, opportunity):
    """Return (0..1, reason, cost_summary or None)."""
    try:
        estimate = estimate_cost(opportunity=opportunity, profile=profile)
    except CostDataMissing:
        return 0.5, 'No cost data for this country yet.', None

    years = max(estimate['duration_months'] / 12, 1 / 12)
    yearly_net = estimate['net_after_part_time_bdt'] / years
    summary = {
        'total_bdt': estimate['total_bdt'],
        'per_year_bdt': estimate['per_year_bdt'],
        'net_after_part_time_bdt': estimate['net_after_part_time_bdt'],
        'assumed_items': estimate['assumed_items'],
    }

    budget = Decimal(profile.annual_budget_bdt or 0)
    if budget <= 0:
        return 0.5, 'Add your annual budget to compare costs.', summary

    ratio = yearly_net / float(budget)
    money = f'৳{estimate["per_year_bdt"]:,} per year'

    if ratio <= 1:
        return 1.0, f'Estimated cost ({money}) fits your budget.', summary
    if ratio <= 1.15:
        return 0.6, f'Estimated cost ({money}) is slightly above your budget.', summary
    if ratio <= 1.4:
        return 0.3, f'Estimated cost ({money}) is well above your budget.', summary
    return 0.0, f'Estimated cost ({money}) is far above your budget.', summary


def score_opportunity(profile, opportunity):
    eligibility = check_eligibility(profile, opportunity)
    statuses = [item['status'] for item in eligibility['criteria_results']]
    points = {'Met': 1.0, 'Unknown': 0.5, 'Not met': 0.0}
    ratio = sum(points[s] for s in statuses) / len(statuses) if statuses else 0.5

    reasons = []
    blockers = [
        item['criterion'] for item in eligibility['criteria_results'] if item['status'] == 'Not met'
    ]

    if blockers:
        reasons.append('Requirement not met: ' + ', '.join(blockers) + '.')
    elif eligibility['overall_status'] == 'Eligible':
        reasons.append('You meet every requirement we could check.')
    else:
        unknown = [i['criterion'] for i in eligibility['criteria_results'] if i['status'] == 'Unknown']
        if unknown:
            reasons.append('Needs checking: ' + ', '.join(unknown[:3]) + '.')

    budget_ratio, budget_reason, cost_summary = _budget_points(profile, opportunity)
    reasons.append(budget_reason)

    preferences = profile.destination_preferences or []
    if preferences:
        dest_ratio = 1.0 if opportunity.country in preferences else 0.0
        reasons.append(
            f'{opportunity.country} is one of your preferred destinations.'
            if dest_ratio else f'{opportunity.country} is not in your preferred destinations.'
        )
    else:
        dest_ratio = 0.5

    field_ratio, field_reason = field_match(profile, opportunity)
    reasons.append(field_reason)

    score = (
        W_ELIGIBILITY * ratio
        + W_BUDGET * budget_ratio
        + W_DESTINATION * dest_ratio
        + W_FIELD * field_ratio
    )

    # A hard "Not met" requirement means this is not a safe suggestion.
    if blockers:
        score = min(score, 45)

    score = round(score)
    label = (
        'Strong match' if score >= 75 else
        'Good match' if score >= 55 else
        'Possible' if score >= 40 else
        'Stretch'
    )

    return {
        'opportunity_id': opportunity.id,
        'title': opportunity.title,
        'institution': opportunity.institution,
        'country': opportunity.country,
        'city': opportunity.city,
        'deadline': opportunity.deadline,
        'verification_status': opportunity.verification_status,
        'is_stale': opportunity.is_stale,
        'source_url': opportunity.source_url,
        'score': score,
        'label': label,
        'eligibility_status': eligibility['overall_status'],
        'reasons': reasons,
        'cost': cost_summary,
    }


def recommend(profile, queryset, limit=20):
    results = [score_opportunity(profile, opp) for opp in queryset]
    results.sort(key=lambda item: item['score'], reverse=True)
    return results[:limit]
