
from datetime import timedelta
from decimal import Decimal

from django.conf import settings
from django.db import models, transaction
from django.utils import timezone


class Opportunity(models.Model):

    TYPE_CHOICES = [
        ('program', 'Study Program'),
        ('scholarship', 'Scholarship'),
    ]

    COUNTRY_CHOICES = [
        ('Germany', 'Germany'),
        ('UK', 'United Kingdom'),
        ('Canada', 'Canada'),
        ('USA', 'United States'),
    ]

    VERIFICATION_CHOICES = [
        ('pending', 'Pending Review'),
        ('verified', 'Verified'),
        ('outdated', 'Outdated'),
        ('expired', 'Expired'),
    ]

    INTAKE_CHOICES = [
        ('winter', 'Winter'),
        ('summer', 'Summer'),
        ('fall', 'Fall'),
        ('spring', 'Spring'),
        ('other', 'Other'),
    ]

    opportunity_type = models.CharField(
        max_length=20,
        choices=TYPE_CHOICES
    )

    title = models.CharField(max_length=255)
    institution = models.CharField(max_length=255)
    country = models.CharField(max_length=50, choices=COUNTRY_CHOICES)
    city = models.CharField(max_length=100, blank=True)

    description = models.TextField(blank=True)
    eligibility_criteria = models.TextField()
    eligibility_rules = models.JSONField(default=dict, blank=True)

    deadline = models.DateField(null=True, blank=True)

    # Money and duration (used by the cost estimator).
    # Leave tuition/fees empty to use the country average and show a warning.
    tuition_per_year = models.DecimalField(
        max_digits=12, decimal_places=2, null=True, blank=True,
        help_text='Tuition per year in the country currency (EUR, GBP, CAD, USD).'
    )
    fees_per_year = models.DecimalField(
        max_digits=12, decimal_places=2, null=True, blank=True,
        help_text='Semester contribution / student fees per year, same currency.'
    )
    duration_months = models.PositiveSmallIntegerField(default=24)

    # Words used by the recommendation engine, e.g. ["computer science", "ai"]
    field_tags = models.JSONField(default=list, blank=True)

    # Legacy general source fields (kept for compatibility)
    source_url = models.URLField()
    verified_on = models.DateField()

    # Verification and freshness
    verification_status = models.CharField(
        max_length=20,
        choices=VERIFICATION_CHOICES,
        default='pending'
    )
    last_checked_at = models.DateTimeField(null=True, blank=True)
    review_notes = models.TextField(blank=True)

    # Academic intake / application cycle
    intake_season = models.CharField(
        max_length=20,
        choices=INTAKE_CHOICES,
        blank=True
    )
    intake_year = models.PositiveSmallIntegerField(null=True, blank=True)
    application_open_date = models.DateField(null=True, blank=True)

    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    HISTORY_FIELDS = [
        'title',
        'institution',
        'country',
        'deadline',
        'tuition_per_year',
        'fees_per_year',
        'eligibility_criteria',
        'eligibility_rules',
        'source_url',
        'verified_on',
        'verification_status',
        'last_checked_at',
        'intake_season',
        'intake_year',
        'application_open_date',
        'is_active',
    ]

    @property
    def is_stale(self):
        if self.last_checked_at is None:
            return True

        return timezone.now() - self.last_checked_at > timedelta(days=90)

    def save(self, *args, **kwargs):
        with transaction.atomic():
            old_values = None

            if self.pk:
                old_values = (
                    type(self).objects
                    .filter(pk=self.pk)
                    .values(*self.HISTORY_FIELDS)
                    .first()
                )

            super().save(*args, **kwargs)

            if old_values is None:
                changes = {
                    field: {
                        'old': None,
                        'new': getattr(self, field)
                    }
                    for field in self.HISTORY_FIELDS
                }
                action = 'created'
            else:
                changes = {}

                for field in self.HISTORY_FIELDS:
                    old_value = old_values[field]
                    new_value = getattr(self, field)

                    if old_value != new_value:
                        changes[field] = {
                            'old': old_value,
                            'new': new_value
                        }

                action = 'updated'

            if changes:
                # Convert dates and other non-JSON values to strings.
                for field_changes in changes.values():
                    for key, value in field_changes.items():
                        if hasattr(value, 'isoformat'):
                            field_changes[key] = value.isoformat()
                        elif isinstance(value, Decimal):
                            field_changes[key] = str(value)

                OpportunityHistory.objects.create(
                    opportunity=self,
                    action=action,
                    changes=changes,
                    changed_by=getattr(self, '_history_user', None)
                )

    def __str__(self):
        return f"{self.title} - {self.country}"


class OpportunitySource(models.Model):

    FACT_CHOICES = [
        ('tuition', 'Tuition Fees'),
        ('admission', 'Admission Requirements'),
        ('english', 'English Requirements'),
        ('deadline', 'Application Deadline'),
        ('scholarship', 'Scholarship Details'),
        ('living_cost', 'Living Costs'),
        ('other', 'Other'),
    ]

    STATUS_CHOICES = [
        ('pending', 'Pending Review'),
        ('verified', 'Verified'),
        ('outdated', 'Outdated'),
        ('expired', 'Expired'),
    ]

    opportunity = models.ForeignKey(
        Opportunity,
        on_delete=models.CASCADE,
        related_name='sources'
    )

    fact_type = models.CharField(
        max_length=30,
        choices=FACT_CHOICES
    )

    source_label = models.CharField(max_length=255, blank=True)
    source_url = models.URLField()

    verification_status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending'
    )

    verified_on = models.DateField(null=True, blank=True)
    last_checked_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['opportunity', 'fact_type', 'source_url'],
                name='unique_opportunity_fact_source'
            )
        ]

    @property
    def is_stale(self):
        if self.last_checked_at is None:
            return True

        return timezone.now() - self.last_checked_at > timedelta(days=90)

    def __str__(self):
        return f"{self.opportunity.title} - {self.get_fact_type_display()}"


class OpportunityHistory(models.Model):

    ACTION_CHOICES = [
        ('created', 'Created'),
        ('updated', 'Updated'),
    ]

    opportunity = models.ForeignKey(
        Opportunity,
        on_delete=models.CASCADE,
        related_name='history'
    )

    action = models.CharField(
        max_length=20,
        choices=ACTION_CHOICES
    )

    changes = models.JSONField(default=dict)

    changed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    changed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-changed_at']

    def __str__(self):
        return f"{self.opportunity.title} - {self.action} - {self.changed_at}"
