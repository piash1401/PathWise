
from datetime import date

from django.test import TestCase
from django.contrib.auth.models import User

from profiles.models import StudentProfile
from .models import Opportunity
from .eligibility import check_eligibility


class EligibilityTestCase(TestCase):

    def setUp(self):
        self.user = User.objects.create_user(
            username="teststudent",
            password="testpassword123"
        )

        self.profile = StudentProfile.objects.create(
            user=self.user,
            highest_degree="Bachelor",
            field_of_study="SWE",
            institution="Test University",
            graduation_year=2026,
            grade="3.92",
            grade_scale="4.00",
            english_test="IELTS",
            overall_score="7.00",
            annual_budget_bdt=500000,
            destination_preferences=["Germany"]
        )

        self.opportunity = Opportunity.objects.create(
            opportunity_type="program",
            title="Test MSc Program",
            institution="Test University",
            country="Germany",
            eligibility_criteria="Test eligibility requirements.",
            eligibility_rules={
                "minimum_grade": 3.0,
                "grade_scale": 4.0,
                "required_fields": [
                    "Computer Science",
                    "Software Engineering"
                ],
                "english_test": {
                    "required": True,
                    "accepted_tests": ["IELTS", "TOEFL", "PTE"],
                    "minimum_overall_scores": {
                        "IELTS": 6.5,
                        "TOEFL": 90,
                        "PTE": 65
                    }
                }
            },
            source_url="https://example.com/program",
            verified_on=date(2026, 11, 11)
        )

    def get_result(self):
        return check_eligibility(
            self.profile,
            self.opportunity
        )

    def test_student_is_eligible(self):
        result = self.get_result()

        self.assertEqual(result["overall_status"], "Eligible")

    def test_minimum_grade_not_met(self):
        self.profile.grade = "2.50"
        self.profile.save()

        result = self.get_result()

        self.assertEqual(
            result["criteria_results"][0]["status"],
            "Not met"
        )
        self.assertEqual(result["overall_status"], "Not eligible")

    def test_academic_field_not_accepted(self):
        self.profile.field_of_study = "Business Administration"
        self.profile.save()

        result = self.get_result()

        self.assertEqual(
            result["criteria_results"][1]["status"],
            "Not met"
        )
        self.assertEqual(result["overall_status"], "Not eligible")

    def test_english_score_not_met(self):
        self.profile.overall_score = "5.50"
        self.profile.save()

        result = self.get_result()

        self.assertEqual(
            result["criteria_results"][2]["status"],
            "Not met"
        )
        self.assertEqual(result["overall_status"], "Not eligible")

    def test_english_test_not_accepted(self):
        self.profile.english_test = "Other"
        self.profile.save()

        result = self.get_result()

        self.assertEqual(
            result["criteria_results"][2]["status"],
            "Not met"
        )

    def test_missing_english_score_returns_unknown(self):
        self.profile.overall_score = None
        self.profile.save()

        result = self.get_result()

        self.assertEqual(
            result["criteria_results"][2]["status"],
            "Unknown"
        )
        self.assertEqual(
            result["overall_status"],
            "Needs more information"
        )

    def test_no_english_test_required(self):
        self.opportunity.eligibility_rules["english_test"] = {
            "required": False
        }

        result = self.get_result()

        self.assertEqual(
            result["criteria_results"][2]["status"],
            "Met"
        )

    def test_missing_field_requirement_returns_unknown(self):
        self.opportunity.eligibility_rules = {
            "minimum_grade": 3.0,
            "grade_scale": 4.0,
            "english_test": {
                "required": True,
                "accepted_tests": ["IELTS"],
                "minimum_overall_scores": {"IELTS": 6.5}
            }
        }

        result = self.get_result()

        self.assertEqual(
            result["criteria_results"][1]["status"],
            "Unknown"
        )
        self.assertEqual(
            result["overall_status"],
            "Needs more information"
        )

    def test_different_grade_scales_return_unknown(self):
        self.profile.grade_scale = "5.00"
        self.profile.grade = "4.50"
        self.profile.save()

        result = self.get_result()

        self.assertEqual(
            result["criteria_results"][0]["status"],
            "Unknown"
        )
        self.assertEqual(
            result["overall_status"],
            "Needs more information"
        )
