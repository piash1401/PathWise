
from decimal import Decimal, InvalidOperation

from .models import Opportunity


def to_decimal(value):
    """Safely convert a value into a finite Decimal."""
    try:
        number = Decimal(str(value))
        return number if number.is_finite() else None
    except (InvalidOperation, ValueError, TypeError):
        return None


def normalize_field(value):
    """Normalize common academic field abbreviations."""
    aliases = {
        "swe": "software engineering",
        "cs": "computer science",
    }

    field = str(value).strip().casefold()
    return aliases.get(field, field)


def check_course_requirements(profile, rules):
    """Evaluate recorded course information without assuming credit equivalence."""
    results = []

    required_categories = rules.get("required_course_categories", [])
    credit_requirements = rules.get("course_credit_requirements", {})

    if not isinstance(required_categories, list):
        required_categories = []

    if not isinstance(credit_requirements, dict):
        credit_requirements = {}

    categories = set(required_categories) | set(credit_requirements.keys())

    if not categories:
        return results

    courses = list(profile.academic_courses.all())

    for category in sorted(categories):
        category_courses = [
            course for course in courses
            if course.category == category
        ]

        recorded_credits = sum(
            (
                to_decimal(course.credits) or Decimal("0")
                for course in category_courses
            ),
            Decimal("0")
        )

        course_names = [
            course.course_name for course in category_courses
        ]

        requirement = credit_requirements.get(category, {})

        if not isinstance(requirement, dict):
            requirement = {}

        minimum_credits = to_decimal(
            requirement.get("minimum_credits")
        )

        # The current AcademicCourse model does not store
        # the credit system (for example, ECTS or local credits).
        # Therefore, numerical credit requirements cannot
        # safely be confirmed.
        status = "Unknown"

        results.append({
            "criterion": f"Course requirement: {category}",
            "status": status,
            "student_value": {
                "courses": course_names,
                "recorded_credits": str(recorded_credits),
            },
            "required_value": {
                "minimum_credits": (
                    str(minimum_credits)
                    if minimum_credits is not None
                    else None
                ),
                "credit_system": requirement.get("credit_system"),
                "note": (
                    "Credit equivalence and course relevance "
                    "require verification."
                ),
            }
        })

    return results


def check_thesis_requirement(profile, rules):
    """Evaluate thesis completion without assuming scientific relevance."""
    if rules.get("thesis_required") is not True:
        return None

    try:
        record = profile.academic_record
    except profile.__class__.DoesNotExist:
        record = None

    if record is None or record.thesis_completed is None:
        status = "Unknown"
        student_value = None

    elif record.thesis_completed is False:
        status = "Not met"
        student_value = {
            "thesis_completed": False,
        }

    else:
        # Completion is recorded, but scientific quality and
        # relevance still require manual verification.
        status = "Unknown"
        student_value = {
            "thesis_completed": True,
            "thesis_title": record.thesis_title,
            "thesis_description": record.thesis_description,
        }

    return {
        "criterion": "Scientific thesis requirement",
        "status": status,
        "student_value": student_value,
        "required_value": (
            "A scientific thesis is required; relevance "
            "must be reviewed."
        ),
    }


def check_eligibility(profile, opportunity):
    rules = opportunity.eligibility_rules or {}

    if not isinstance(rules, dict):
        rules = {}

    results = []

    # 1. Minimum academic grade
    if "minimum_grade" not in rules or "grade_scale" not in rules:
        grade_status = "Unknown"
        required_grade = rules.get("minimum_grade")
    else:
        student_grade = to_decimal(profile.grade)
        student_scale = to_decimal(profile.grade_scale)
        required_grade = to_decimal(rules["minimum_grade"])
        required_scale = to_decimal(rules["grade_scale"])

        if (
            student_grade is None
            or student_scale is None
            or required_grade is None
            or required_scale is None
            or student_scale <= 0
            or required_scale <= 0
            or student_grade < 0
            or student_grade > student_scale
            or required_grade < 0
            or required_grade > required_scale
        ):
            grade_status = "Unknown"

        elif student_scale != required_scale:
            grade_status = "Unknown"

        elif student_grade >= required_grade:
            grade_status = "Met"

        else:
            grade_status = "Not met"

    results.append({
        "criterion": "Minimum academic grade",
        "status": grade_status,
        "student_value": str(profile.grade),
        "required_value": (
            f'{rules["minimum_grade"]}/{rules["grade_scale"]}'
            if "minimum_grade" in rules and "grade_scale" in rules
            else required_grade
        )
    })

    # 2. Required academic field
    accepted_fields = rules.get("required_fields")
    student_field = (profile.field_of_study or "").strip()

    if (
        not isinstance(accepted_fields, list)
        or not accepted_fields
        or not student_field
        or not all(
            isinstance(field, str) and field.strip()
            for field in accepted_fields
        )
    ):
        field_status = "Unknown"
    else:
        normalized_student = normalize_field(student_field)

        normalized_accepted = [
            normalize_field(field)
            for field in accepted_fields
        ]

        field_status = (
            "Met"
            if normalized_student in normalized_accepted
            else "Not met"
        )

    results.append({
        "criterion": "Required academic field",
        "status": field_status,
        "student_value": student_field or None,
        "required_value": accepted_fields
    })

    # 3. English proficiency
    english_rules = rules.get("english_test")

    if not isinstance(english_rules, dict):
        english_status = "Unknown"
        required_english = None

    elif english_rules.get("required") is False:
        english_status = "Met"
        required_english = "No English test required"

    elif english_rules.get("required") is not True:
        english_status = "Unknown"
        required_english = None

    else:
        accepted_tests = english_rules.get("accepted_tests")
        minimum_scores = english_rules.get("minimum_overall_scores")

        student_test = (profile.english_test or "").strip().upper()
        student_score = to_decimal(profile.overall_score)

        if (
            not isinstance(accepted_tests, list)
            or not accepted_tests
            or not isinstance(minimum_scores, dict)
        ):
            english_status = "Unknown"
            required_english = None

        elif not student_test or student_score is None:
            english_status = "Unknown"
            required_english = minimum_scores

        else:
            normalized_tests = [
                test.strip().upper()
                for test in accepted_tests
                if isinstance(test, str) and test.strip()
            ]

            if student_test not in normalized_tests:
                english_status = "Not met"
                required_english = accepted_tests

            elif student_test not in minimum_scores:
                english_status = "Unknown"
                required_english = minimum_scores

            else:
                required_score = to_decimal(
                    minimum_scores[student_test]
                )

                if required_score is None:
                    english_status = "Unknown"
                elif student_score >= required_score:
                    english_status = "Met"
                else:
                    english_status = "Not met"

                required_english = {
                    student_test: minimum_scores[student_test]
                }

    results.append({
        "criterion": "English proficiency",
        "status": english_status,
        "student_value": {
            "test": profile.english_test or None,
            "overall_score": (
                str(profile.overall_score)
                if profile.overall_score is not None
                else None
            )
        },
        "required_value": required_english
    })

    # 4. Individual academic course requirements
    results.extend(check_course_requirements(profile, rules))

    # 5. Scientific thesis requirement
    thesis_result = check_thesis_requirement(profile, rules)

    if thesis_result:
        results.append(thesis_result)

    # 6. Other requirements needing manual evaluation
    manual_requirements = rules.get("manual_review_requirements")
    manual_review_required = rules.get("manual_review_required", False)

    if manual_review_required or (
        isinstance(manual_requirements, list)
        and len(manual_requirements) > 0
    ):
        results.append({
            "criterion": "Additional academic requirements",
            "status": "Unknown",
            "student_value": None,
            "required_value": (
                manual_requirements
                if isinstance(manual_requirements, list)
                else ["Additional requirements need manual review."]
            )
        })

    # 7. Overall eligibility
    statuses = [item["status"] for item in results]

    if "Not met" in statuses:
        overall_status = "Not eligible"
    elif "Unknown" in statuses:
        overall_status = "Needs more information"
    else:
        overall_status = "Eligible"

    return {
        "opportunity": opportunity.title,
        "overall_status": overall_status,
        "criteria_results": results
    }
