
from django.contrib import admin

from .models import (
    Opportunity,
    OpportunitySource,
    OpportunityHistory,
)


class OpportunitySourceInline(admin.TabularInline):
    model = OpportunitySource
    extra = 1


class OpportunityHistoryInline(admin.TabularInline):
    model = OpportunityHistory
    extra = 0
    can_delete = False

    readonly_fields = (
        'action',
        'changes',
        'changed_by',
        'changed_at',
    )

    def has_add_permission(self, request, obj=None):
        return False


@admin.register(Opportunity)
class OpportunityAdmin(admin.ModelAdmin):

    list_display = (
        'title',
        'opportunity_type',
        'institution',
        'country',
        'intake_season',
        'intake_year',
        'deadline',
        'verification_status',
        'freshness',
        'is_active',
    )

    list_filter = (
        'opportunity_type',
        'country',
        'verification_status',
        'intake_season',
        'is_active',
    )

    search_fields = (
        'title',
        'institution',
        'country',
    )

    readonly_fields = (
        'created_at',
        'updated_at',
    )

    inlines = [
        OpportunitySourceInline,
        OpportunityHistoryInline,
    ]

    @admin.display(description='Freshness')
    def freshness(self, obj):
        return 'Stale' if obj.is_stale else 'Current'

    def save_model(self, request, obj, form, change):
        obj._history_user = request.user
        super().save_model(request, obj, form, change)
