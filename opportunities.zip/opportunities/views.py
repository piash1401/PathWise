
from datetime import timedelta

from django.db.models import Q
from django.shortcuts import get_object_or_404
from django.utils import timezone

from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Opportunity
from .serializers import OpportunitySerializer
from .eligibility import check_eligibility
from .recommendations import recommend
from profiles.models import StudentProfile


class OpportunityListView(generics.ListAPIView):
    serializer_class = OpportunitySerializer

    def get_queryset(self):
        queryset = Opportunity.objects.filter(is_active=True)
        params = self.request.query_params

        # Free-text search over title, institution and city
        search = params.get('q', '').strip()
        if search:
            queryset = queryset.filter(
                Q(title__icontains=search)
                | Q(institution__icontains=search)
                | Q(city__icontains=search)
            )

        # Filter by opportunity type
        opportunity_type = params.get('type')
        if opportunity_type:
            queryset = queryset.filter(opportunity_type=opportunity_type)

        # Filter by country
        country = params.get('country')
        if country:
            queryset = queryset.filter(country=country)

        # Filter by verification status
        verification_status = params.get('verification_status')
        if verification_status:
            queryset = queryset.filter(verification_status=verification_status)

        # Filter by intake season
        intake_season = params.get('intake_season')
        if intake_season:
            queryset = queryset.filter(intake_season=intake_season)

        # Filter by intake year
        intake_year = params.get('intake_year')
        if intake_year:
            queryset = queryset.filter(intake_year=intake_year)

        # Filter by freshness
        stale = params.get('stale')
        cutoff = timezone.now() - timedelta(days=90)

        if stale == 'true':
            queryset = queryset.filter(
                Q(last_checked_at__isnull=True)
                | Q(last_checked_at__lt=cutoff)
            )
        elif stale == 'false':
            queryset = queryset.filter(last_checked_at__gte=cutoff)

        return queryset.order_by('country', 'title').prefetch_related('sources')


class OpportunityDetailView(generics.RetrieveAPIView):
    serializer_class = OpportunitySerializer

    def get_queryset(self):
        return Opportunity.objects.filter(is_active=True).prefetch_related('sources')


class EligibilityCheckView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, opportunity_id):
        profile = get_object_or_404(
            StudentProfile,
            user=request.user
        )

        opportunity = get_object_or_404(
            Opportunity,
            id=opportunity_id,
            is_active=True
        )

        result = check_eligibility(profile, opportunity)

        return Response(result, status=status.HTTP_200_OK)


class RecommendationView(APIView):
    """GET /api/opportunities/recommendations/?country=Germany&limit=10"""
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        profile = StudentProfile.objects.filter(user=request.user).first()

        if profile is None:
            return Response(
                {'error': 'Complete your profile first so we can match programs to you.'},
                status=status.HTTP_404_NOT_FOUND,
            )

        queryset = Opportunity.objects.filter(is_active=True, opportunity_type='program')

        country = request.query_params.get('country')
        if country:
            queryset = queryset.filter(country=country)

        try:
            limit = max(1, min(50, int(request.query_params.get('limit', 20))))
        except ValueError:
            limit = 20

        return Response({
            'results': recommend(profile, queryset, limit),
            'scoring': {
                'eligibility': 40, 'budget': 25, 'destination': 15, 'field': 20,
                'note': 'Scores are guidance, not admission chances.',
            },
        })
