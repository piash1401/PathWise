
from django.urls import path

from .views import (
    OpportunityListView,
    OpportunityDetailView,
    EligibilityCheckView,
    RecommendationView,
)


urlpatterns = [
    path(
        '',
        OpportunityListView.as_view(),
        name='opportunity-list'
    ),
    path(
        'recommendations/',
        RecommendationView.as_view(),
        name='recommendations'
    ),
    path(
        '<int:pk>/',
        OpportunityDetailView.as_view(),
        name='opportunity-detail'
    ),
    path(
        '<int:opportunity_id>/check-eligibility/',
        EligibilityCheckView.as_view(),
        name='check-eligibility'
    ),
]
